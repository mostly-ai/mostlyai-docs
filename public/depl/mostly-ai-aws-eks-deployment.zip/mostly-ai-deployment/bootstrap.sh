#!/bin/bash

set -e
region=$1
profile=$2
if [[ -z $region ]]; then
    echo "Region is not set."
    exit 1
fi

if [[ -z $profile ]]; then
    echo "Profile is not set."
else
    export AWS_DEFAULT_PROFILE=$profile
fi

check_command() {
    command -v $1 >/dev/null 2>&1
    if [[ $? -ne 0 ]]; then
        echo "$1 is not installed."
        exit 1
    else
        echo "$1 is installed."
    fi
}

check_command aws
check_command jq
check_command helm
check_command kubectl
check_command awk
check_command grep

aws cloudformation create-stack --stack-name mostlyai-eks \
    --template-body file://eks-cluster.yaml \
    --region $region \
    --capabilities CAPABILITY_IAM \
    --no-cli-pager

while true; do
    STACK_STATUS=$(aws cloudformation describe-stacks --stack-name mostlyai-eks --region $region --query 'Stacks[0].StackStatus' --output text)

    if [[ $STACK_STATUS == "CREATE_COMPLETE" ]]; then
        echo "Stack creation complete"
        break
    elif [[ $STACK_STATUS == "ROLLBACK_COMPLETE" || $STACK_STATUS == "ROLLBACK_IN_PROGRESS" || $STACK_STATUS == "CREATE_FAILED" ]]; then
        echo "Stack creation failed"
        exit 1
    else
        echo "Stack status: $STACK_STATUS. Waiting for stack creation to complete..."
        sleep 30  # wait for 30 seconds before checking again
    fi
done

export account_id=$(aws sts get-caller-identity --query Account --output text --no-cli-pager)
sleep 5
aws iam create-policy \
    --policy-name MOSTLYAI_POLICY \
    --policy-document file://mostly-policy.json \
    --no-cli-pager

sleep 10
aws iam create-user --user-name MOSTLY_USER --no-cli-pager

sleep 10
output=$(aws iam create-access-key --user-name MOSTLY_USER)
export AWS_ACCESS_KEY=$(echo $output | jq -r '.AccessKey.AccessKeyId')
export AWS_SECRET_KEY=$(echo $output | jq -r '.AccessKey.SecretAccessKey')


aws iam attach-user-policy --user-name MOSTLY_USER --policy-arn arn:aws:iam::$account_id:policy/MOSTLYAI_POLICY
sleep 10
aws eks update-kubeconfig --name mostlyai-eks --region $region
sleep 10

kubectl create namespace mostly-ai
sleep 10

kubectl -n kube-system get configmap/aws-auth -o=json | jq --arg account_id "$account_id" '.data.mapUsers += "- userarn: arn:aws:iam::" + $account_id + ":user/MOSTLY_USER\n  username: MOSTLY_USER\n  groups:\n  - system:masters\n"' | kubectl apply -f -
sleep 10

helm install mostly-bootstrap --values values.yaml ./ -n mostly-ai \
    --set accessKey=$AWS_ACCESS_KEY \
    --set secretKey=$AWS_SECRET_KEY \
    --set region=$region \
    --set clusterName=mostlyai-eks \
    --set stackName=mostlyai-eks

echo "Waiting for bootstrap to complete... It will take around 20-30 minutes. Please be patient."
sleep 1500
kubectl logs `kubectl get pods -n mostly-ai |grep mostly-bootstrap |awk -F ' ' {'print $1'}` -n mostly-ai
echo "#########"
echo "Please use below AWS ALB address to point your domain to it with AWS Route 53 or any other provider."
echo "Please don't cancel or close this terminal tab as it will offer some important information at the end!"
kubectl get ingress mostly-ui -n mostly-ai
#kubectl delete pod $(kubectl get pods | awk '{print $1}' | grep mostly-bootstrap)
echo "#########"